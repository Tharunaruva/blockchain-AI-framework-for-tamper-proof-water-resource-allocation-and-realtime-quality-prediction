import sys
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import csv
import hashlib

INPUT_FILE  = "outputs/water_data.csv"
OUTPUT_FILE = "outputs/blockchain_log.csv"

# ── WHO thresholds (same as detect_anomalies.py) ─────────────────────────────
def classify_status(row):
    ph   = float(row["pH"])
    turb = float(row["turbidity"])
    do   = float(row["dissolved_oxygen"])
    temp = float(row["temperature"])
    if (ph < 6.5 or ph > 8.5 or
            turb > 4.0 or
            do   < 5.0 or
            temp > 30.0):
        return "ANOMALY"
    return "NORMAL"

# ── SHA-256 helper ────────────────────────────────────────────────────────────
def compute_hash(prev_hash, timestamp, ph, turbidity, dissolved_oxygen, flow_rate):
    raw = f"{prev_hash}{timestamp}{ph}{turbidity}{dissolved_oxygen}{flow_rate}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()

# ── Load source data ──────────────────────────────────────────────────────────
source_rows = []
with open(INPUT_FILE, newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        source_rows.append(row)

# ── Build the chain ───────────────────────────────────────────────────────────
blockchain = []
prev_hash  = "GENESIS"

for idx, row in enumerate(source_rows):
    ts   = row["timestamp"]
    ph   = row["pH"]
    turb = row["turbidity"]
    do   = row["dissolved_oxygen"]
    fr   = row["flow_rate"]

    current_hash = compute_hash(prev_hash, ts, ph, turb, do, fr)
    status       = classify_status(row)

    block = {
        "block_index":       idx,
        "timestamp":         ts,
        "location":          row["location"],
        "pH":                ph,
        "turbidity":         turb,
        "dissolved_oxygen":  do,
        "flow_rate":         fr,
        "status":            status,
        "previous_hash":     prev_hash,
        "current_hash":      current_hash,
    }
    blockchain.append(block)
    prev_hash = current_hash

# ── Save blockchain log ───────────────────────────────────────────────────────
fieldnames = [
    "block_index", "timestamp", "location",
    "pH", "turbidity", "dissolved_oxygen", "flow_rate",
    "status", "previous_hash", "current_hash",
]
with open(OUTPUT_FILE, "w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(blockchain)

# ── Integrity verification (re-walk the chain) ────────────────────────────────
print("=" * 72)
print("  BLOCKCHAIN BUILDER — Tamper-Proof Water Ledger")
print("  Algorithm: SHA-256  |  Genesis anchor: 'GENESIS'")
print("=" * 72)

anomaly_count = sum(1 for b in blockchain if b["status"] == "ANOMALY")
normal_count  = len(blockchain) - anomaly_count

print(f"\n  Input file   : {INPUT_FILE}")
print(f"  Output file  : {OUTPUT_FILE}")
print(f"\n  ┌──────────────────────────────────────────────────────────────┐")
print(f"  │  Blocks written   : {len(blockchain):<43}│")
print(f"  │  NORMAL blocks    : {normal_count:<43}│")
print(f"  │  ANOMALY blocks   : {anomaly_count:<43}│")
print(f"  └──────────────────────────────────────────────────────────────┘")

# Show first 3 and last block for inspection
print("\n  Block preview (genesis → block 2):\n")
for b in blockchain[:3]:
    print(f"    Block #{b['block_index']:>02}  [{b['status']:>6}]  {b['timestamp']}  {b['location']}")
    print(f"    prev  : {b['previous_hash'][:24]}...")
    print(f"    hash  : {b['current_hash'][:24]}...")
    print()

last = blockchain[-1]
print(f"  Final block  #{last['block_index']:>02}  [{last['status']:>6}]  {last['timestamp']}  {last['location']}")
print(f"    prev  : {last['previous_hash'][:24]}...")
print(f"    hash  : {last['current_hash'][:24]}...")

print(f"\n  Blockchain built with {len(blockchain)} blocks.\n")
print("=" * 72)
