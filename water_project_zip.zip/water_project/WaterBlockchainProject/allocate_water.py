import sys
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import csv

INPUT_FILE  = "outputs/water_data.csv"
OUTPUT_FILE = "outputs/allocation_output.csv"

# ── Load data ────────────────────────────────────────────────────────────────
rows = []
with open(INPUT_FILE, newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        rows.append(row)

# ── Calculate overall average flow rate ──────────────────────────────────────
flow_values = [float(r["flow_rate"]) for r in rows]
average_flow = round(sum(flow_values) / len(flow_values), 2)

# ── Determine allocation tier & percentages ───────────────────────────────────
if average_flow > 500:
    tier          = "High"
    agri_pct      = 60
    industry_pct  = 25
    domestic_pct  = 15
elif 300 <= average_flow <= 500:
    tier          = "Medium"
    agri_pct      = 50
    industry_pct  = 20
    domestic_pct  = 30
else:                           # below 300
    tier          = "Low"
    agri_pct      = 30
    industry_pct  = 15
    domestic_pct  = 55

# ── Build output rows (one per source row) ────────────────────────────────────
output_rows = []
for r in rows:
    output_rows.append({
        "timestamp":          r["timestamp"],
        "location":           r["location"],
        "average_flow":       average_flow,
        "agriculture_percent":agri_pct,
        "industry_percent":   industry_pct,
        "domestic_percent":   domestic_pct,
        "allocation_tier":    tier,
    })

# ── Save to CSV ───────────────────────────────────────────────────────────────
fieldnames = [
    "timestamp", "location", "average_flow",
    "agriculture_percent", "industry_percent", "domestic_percent",
    "allocation_tier",
]
with open(OUTPUT_FILE, "w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(output_rows)

# ── Terminal report ───────────────────────────────────────────────────────────
bar_agri     = "█" * agri_pct
bar_industry = "█" * industry_pct
bar_domestic = "█" * domestic_pct

print("=" * 65)
print("  WATER RESOURCE ALLOCATION ENGINE")
print("  Blockchain-AI Framework — Allocation Decision")
print("=" * 65)
print(f"\n  Input file      : {INPUT_FILE}")
print(f"  Output file     : {OUTPUT_FILE}")
print(f"  Total readings  : {len(rows)}")
print()
print(f"  ┌─────────────────────────────────────────────┐")
print(f"  │  Average Flow Rate  :  {average_flow:>8.2f} L/s          │")
print(f"  │  Allocation Tier    :  {tier:<22}│")
print(f"  └─────────────────────────────────────────────┘")
print()
print("  Allocation Breakdown:")
print(f"  {'Agriculture':<14} {agri_pct:>3}%  {bar_agri}")
print(f"  {'Industry':<14} {industry_pct:>3}%  {bar_industry}")
print(f"  {'Domestic':<14} {domestic_pct:>3}%  {bar_domestic}")
print()

tier_rules = {
    "High":   "Flow > 500 L/s   → Agri 60% | Ind 25% | Dom 15%",
    "Medium": "300–500 L/s      → Agri 50% | Ind 20% | Dom 30%",
    "Low":    "Flow < 300 L/s   → Agri 30% | Ind 15% | Dom 55%",
}
print(f"  Rule applied  :  {tier_rules[tier]}")
print(f"\n  {OUTPUT_FILE} saved with {len(output_rows)} rows.\n")
print("=" * 65)
