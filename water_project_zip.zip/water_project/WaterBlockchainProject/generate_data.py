import sys
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import csv
import random
from datetime import datetime, timedelta

random.seed(42)

locations = ["River-A", "Lake-B", "Reservoir-C"]

start_time = datetime(2024, 1, 1, 0, 0)
rows = []

for i in range(50):
    timestamp = start_time + timedelta(minutes=30 * i)
    ph = round(random.uniform(6.5, 8.5), 2)
    turbidity = round(random.uniform(0.5, 3.5), 2)
    dissolved_oxygen = round(random.uniform(5.5, 9.5), 2)
    flow_rate = round(random.uniform(100, 800), 1)
    temperature = round(random.uniform(18, 32), 1)
    location = random.choice(locations)

    rows.append({
        "timestamp": timestamp.strftime("%Y-%m-%d %H:%M:%S"),
        "pH": ph,
        "turbidity": turbidity,
        "dissolved_oxygen": dissolved_oxygen,
        "flow_rate": flow_rate,
        "temperature": temperature,
        "location": location
    })

# Inject 6 bad readings randomly (contamination events)
bad_indices = random.sample(range(50), 6)
for idx in bad_indices:
    contamination_type = random.choice(["low_ph", "high_turbidity"])
    if contamination_type == "low_ph":
        rows[idx]["pH"] = round(random.uniform(5.8, 6.19), 2)
    else:
        rows[idx]["turbidity"] = round(random.uniform(5.01, 6.5), 2)

# Write to CSV
fieldnames = ["timestamp", "pH", "turbidity", "dissolved_oxygen", "flow_rate", "temperature", "location"]

import os
os.makedirs("outputs", exist_ok=True)

with open("outputs/water_data.csv", "w", newline="") as csvfile:
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(rows)

print("water_data.csv generated with 50 rows")
print(f"Contamination events injected at row indices: {sorted(bad_indices)}")
