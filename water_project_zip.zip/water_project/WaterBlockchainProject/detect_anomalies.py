import sys
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import csv

# WHO Water Quality Standards
WHO_STANDARDS = {
    "pH":               {"min": 6.5,  "max": 8.5,  "unit": ""},
    "turbidity":        {"max": 4.0,               "unit": "NTU"},
    "dissolved_oxygen": {"min": 5.0,               "unit": "mg/L"},
    "temperature":      {"max": 30.0,              "unit": "°C"},
}

INPUT_FILE  = "outputs/water_data.csv"
OUTPUT_FILE = "outputs/anomalies.csv"

anomalies = []

with open(INPUT_FILE, newline="") as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        reasons = []

        ph    = float(row["pH"])
        turb  = float(row["turbidity"])
        do    = float(row["dissolved_oxygen"])
        temp  = float(row["temperature"])

        # pH check
        if ph < WHO_STANDARDS["pH"]["min"]:
            reasons.append(
                f"pH {ph} is below minimum {WHO_STANDARDS['pH']['min']}"
            )
        elif ph > WHO_STANDARDS["pH"]["max"]:
            reasons.append(
                f"pH {ph} exceeds maximum {WHO_STANDARDS['pH']['max']}"
            )

        # Turbidity check
        if turb > WHO_STANDARDS["turbidity"]["max"]:
            reasons.append(
                f"turbidity {turb} NTU exceeds maximum {WHO_STANDARDS['turbidity']['max']} NTU"
            )

        # Dissolved oxygen check
        if do < WHO_STANDARDS["dissolved_oxygen"]["min"]:
            reasons.append(
                f"dissolved_oxygen {do} mg/L is below minimum {WHO_STANDARDS['dissolved_oxygen']['min']} mg/L"
            )

        # Temperature check
        if temp > WHO_STANDARDS["temperature"]["max"]:
            reasons.append(
                f"temperature {temp}°C exceeds maximum {WHO_STANDARDS['temperature']['max']}°C"
            )

        if reasons:
            flagged_row = dict(row)
            flagged_row["reason"] = "; ".join(reasons)
            anomalies.append(flagged_row)

# Write anomalies to CSV
if anomalies:
    fieldnames = list(anomalies[0].keys())
    with open(OUTPUT_FILE, "w", newline="") as outfile:
        writer = csv.DictWriter(outfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(anomalies)

# Terminal report
print("=" * 70)
print("  WATER QUALITY ANOMALY DETECTION REPORT")
print("  Standards: WHO Drinking-Water Quality Guidelines")
print("=" * 70)
print(f"\n  Input file  : {INPUT_FILE}")
print(f"  Output file : {OUTPUT_FILE}")
print(f"\n  Total rows scanned : 50")
print(f"  Anomalies detected : {len(anomalies)}")
print()
print("-" * 70)
print(f"  {'#':<4} {'Timestamp':<22} {'Location':<14} {'Reason'}")
print("-" * 70)
for i, row in enumerate(anomalies, 1):
    print(f"  {i:<4} {row['timestamp']:<22} {row['location']:<14} {row['reason']}")
print("-" * 70)
print(f"\n  anomalies.csv saved with {len(anomalies)} flagged rows.\n")
