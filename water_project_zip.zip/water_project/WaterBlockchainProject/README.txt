================================================================================
  BLOCKCHAIN AI WATER RESOURCE MANAGEMENT SYSTEM
  Tamper-Proof Water Resource Allocation & Real-Time Quality Prediction
================================================================================

PROJECT OVERVIEW
----------------
This project simulates a blockchain-backed water management framework that:
  - Generates realistic water sensor data from multiple locations
  - Detects contamination events against WHO water quality standards
  - Allocates water resources based on live flow rates
  - Builds a SHA-256 chained tamper-proof ledger of all readings
  - Verifies blockchain integrity to detect any data manipulation
  - Produces a full HTML dashboard report of all findings

--------------------------------------------------------------------------------
HOW TO RUN THE PROJECT
--------------------------------------------------------------------------------

  QUICKSTART (recommended):
  --------------------------
  Simply run the master pipeline from inside this folder:

      cd WaterBlockchainProject
      python run_pipeline.py

  This executes all 6 scripts in the correct order and prints a live progress
  log. All output files are written to the outputs/ subfolder.
  When complete, open outputs/water_report.html in any browser to view the
  full dashboard.

  INDIVIDUAL SCRIPTS (manual order):
  ------------------------------------
  If you want to run each step separately, execute them in this exact order:

      python generate_data.py       →  Step 1: Create sensor data
      python detect_anomalies.py    →  Step 2: Flag WHO violations
      python allocate_water.py      →  Step 3: Compute allocation
      python build_blockchain.py    →  Step 4: Build hash chain
      python verify_blockchain.py   →  Step 5: Verify integrity
      python generate_report.py     →  Step 6: Generate HTML report

  NOTE: Scripts must be run from inside the WaterBlockchainProject/ folder so
  they can find their input/output files correctly.

--------------------------------------------------------------------------------
SCRIPT DESCRIPTIONS
--------------------------------------------------------------------------------

  generate_data.py
  ----------------
  Generates 50 rows of realistic fake water sensor data and saves them to
  water_data.csv. Each row contains a timestamp (every 30 minutes from
  2024-01-01 00:00), pH, turbidity, dissolved oxygen, flow rate, temperature,
  and location (River-A, Lake-B, or Reservoir-C). Six bad readings are
  deliberately injected to simulate contamination events (low pH or high
  turbidity). Output: outputs/water_data.csv

  detect_anomalies.py
  --------------------
  Reads water_data.csv and checks every row against WHO drinking-water quality
  guidelines:
    - pH must be between 6.5 and 8.5
    - Turbidity must be below 4.0 NTU
    - Dissolved oxygen must be above 5.0 mg/L
    - Temperature must be below 30°C
  Any row that fails one or more checks is flagged as an anomaly and written to
  anomalies.csv with an extra "reason" column explaining the failure.
  Output: outputs/anomalies.csv

  allocate_water.py
  -----------------
  Reads water_data.csv, calculates the overall average flow rate across all
  readings, and applies tiered allocation rules:
    - High   (flow > 500 L/s)  → Agriculture 60%, Industry 25%, Domestic 15%
    - Medium (300–500 L/s)     → Agriculture 50%, Industry 20%, Domestic 30%
    - Low    (flow < 300 L/s)  → Agriculture 30%, Industry 15%, Domestic 55%
  The allocation decision is applied to every row and saved as a new CSV.
  Output: outputs/allocation_output.csv

  build_blockchain.py
  --------------------
  Reads water_data.csv row by row and constructs a tamper-proof SHA-256 hash
  chain. For each block, the hash is computed from:
      SHA256(previous_hash + timestamp + pH + turbidity + DO + flow_rate)
  The first block uses "GENESIS" as its previous hash. Each block records its
  index, sensor data, WHO status (NORMAL/ANOMALY), and both the previous and
  current hash values.
  Output: outputs/blockchain_log.csv

  verify_blockchain.py
  ---------------------
  Reads blockchain_log.csv and re-computes the SHA-256 hash for every block
  from scratch using the same formula. Compares each recomputed hash against
  the stored current_hash. If all hashes match, the chain is declared intact.
  If any hash differs, the exact block index is reported as tampered.
  This is the core tamper-detection mechanism of the system.

  generate_report.py
  -------------------
  Reads all four CSVs (water_data.csv, anomalies.csv, allocation_output.csv,
  blockchain_log.csv) and generates a professional HTML dashboard. The report
  includes:
    - System summary (total readings, anomalies, allocation tier, integrity)
    - Full water quality table (red rows = anomaly, green = normal)
    - Anomaly detail table with failure reasons
    - Visual allocation bars for Agriculture, Industry, and Domestic sectors
    - Blockchain log showing last 10 blocks with truncated hash values
    - Footer: "All records secured by SHA-256 hash chain"
  Output: outputs/water_report.html

  run_pipeline.py
  ----------------
  Master orchestration script. Runs all six scripts above in the correct order
  using Python's subprocess module. Prints a live progress bar, per-step
  timing, and a final summary table. If any script fails, the pipeline halts
  immediately and prints the error. On success, prints:
      PIPELINE COMPLETE - Open water_report.html to view results

--------------------------------------------------------------------------------
OUTPUT FILES (all written to outputs/)
--------------------------------------------------------------------------------

  water_data.csv          50 rows of simulated water sensor readings
  anomalies.csv           Rows that failed WHO quality standards + reasons
  allocation_output.csv   Flow-based water allocation per reading
  blockchain_log.csv      SHA-256 chained tamper-proof block ledger
  water_report.html       Full HTML dashboard — open in any browser

--------------------------------------------------------------------------------
SYSTEM REQUIREMENTS
--------------------------------------------------------------------------------

  - Python 3.7 or higher
  - No external libraries required (uses only: csv, hashlib, datetime,
    subprocess, sys, time, random — all standard library)

--------------------------------------------------------------------------------
PROJECT STRUCTURE
--------------------------------------------------------------------------------

  WaterBlockchainProject/
  ├── README.txt                  ← This file
  ├── run_pipeline.py             ← Master pipeline (run this first)
  ├── generate_data.py            ← Step 1: Sensor data generation
  ├── detect_anomalies.py         ← Step 2: WHO anomaly detection
  ├── allocate_water.py           ← Step 3: Flow-based allocation
  ├── build_blockchain.py         ← Step 4: SHA-256 blockchain builder
  ├── verify_blockchain.py        ← Step 5: Tamper-proof verifier
  ├── generate_report.py          ← Step 6: HTML dashboard generator
  └── outputs/
      ├── water_data.csv
      ├── anomalies.csv
      ├── allocation_output.csv
      ├── blockchain_log.csv
      └── water_report.html

================================================================================
  Blockchain AI Framework — Tamper-Proof Water Resource Allocation
  & Real-Time Quality Prediction
================================================================================
