import sys
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import csv
import hashlib

BLOCKCHAIN_FILE = "outputs/blockchain_log.csv"

# ── SHA-256 helper (identical formula used in build_blockchain.py) ─────────────
def compute_hash(prev_hash, timestamp, ph, turbidity, dissolved_oxygen, flow_rate):
    raw = f"{prev_hash}{timestamp}{ph}{turbidity}{dissolved_oxygen}{flow_rate}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()

# ── Load blockchain log ────────────────────────────────────────────────────────
blocks = []
with open(BLOCKCHAIN_FILE, newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        blocks.append(row)

total_blocks  = len(blocks)
tampered      = []          # list of dicts describing each failed block
chain_broken  = []          # list of indices where prev_hash linkage snapped

print("=" * 72)
print("  BLOCKCHAIN INTEGRITY VERIFIER")
print("  Algorithm : SHA-256  |  Anchor : GENESIS")
print("=" * 72)
print(f"\n  File         : {BLOCKCHAIN_FILE}")
print(f"  Total blocks : {total_blocks}")
print(f"\n  Verifying chain ...\n")

# ── Re-compute and compare every block ────────────────────────────────────────
for i, block in enumerate(blocks):
    idx          = int(block["block_index"])
    stored_hash  = block["current_hash"]
    prev_hash    = block["previous_hash"]

    recomputed   = compute_hash(
        prev_hash,
        block["timestamp"],
        block["pH"],
        block["turbidity"],
        block["dissolved_oxygen"],
        block["flow_rate"],
    )

    hash_ok      = (recomputed == stored_hash)

    # Check prev_hash linkage (skip genesis)
    if i > 0:
        expected_prev = blocks[i - 1]["current_hash"]
        if prev_hash != expected_prev:
            chain_broken.append(idx)

    if not hash_ok:
        tampered.append({
            "index":      idx,
            "timestamp":  block["timestamp"],
            "location":   block["location"],
            "stored":     stored_hash,
            "recomputed": recomputed,
        })

    # Per-block status line
    mark = "✓" if hash_ok else "✗"
    print(f"  [{mark}] Block #{idx:>02}  {block['timestamp']}  {block['location']:<14}  {block['status']}")

# ── Final verdict ──────────────────────────────────────────────────────────────
print()
print("=" * 72)

all_issues = tampered + [{"index": i} for i in chain_broken]

if not tampered and not chain_broken:
    print(f"\n  ✅  BLOCKCHAIN INTEGRITY VERIFIED — No tampering detected.")
    print(f"      All {total_blocks} blocks are valid.\n")
else:
    print(f"\n  🚨  TAMPERING DETECTED!\n")

    if tampered:
        for t in tampered:
            print(f"  ✗  Block #{t['index']:>02}  [{t['timestamp']}]  {t['location'] if 'location' in t else ''}")
            print(f"     Stored hash     : {t['stored']}")
            print(f"     Recomputed hash : {t['recomputed']}")
            print(f"     → TAMPERING DETECTED at block index {t['index']} — Data has been altered!")
            print()

    if chain_broken:
        for idx in chain_broken:
            print(f"  ✗  Block #{idx:>02} — previous_hash linkage broken (chain severed after block {idx - 1})")
            print()

    valid_count = total_blocks - len(tampered)
    print(f"  Summary : {len(tampered)} tampered block(s), {len(chain_broken)} broken link(s), "
          f"{valid_count} clean block(s) out of {total_blocks}.\n")

print("=" * 72)
